#Bài 7
import math
h = int(input("Nhap do cao h(m): "))
g = 9.8 
v = math.sqrt(2*g*h)
print(f"van toc cua vat khi roi tu do la: {v:.2f} ")
