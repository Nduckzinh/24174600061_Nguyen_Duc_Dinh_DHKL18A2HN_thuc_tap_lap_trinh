#Bài 4
do_c = int(input("Nhap nhiet do (do C): "))
do_k = do_c + 273.15
print(f"Nhiet do theo do K la: {do_k}")