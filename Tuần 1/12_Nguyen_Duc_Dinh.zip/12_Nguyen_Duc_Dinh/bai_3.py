#Bài 3
import math
x = int(input("Nhap vao so x: "))
f = (-x + math.sqrt(x**2 + 4))/((x**4+1)**1/7)
print(f"ket qua la: {f}")