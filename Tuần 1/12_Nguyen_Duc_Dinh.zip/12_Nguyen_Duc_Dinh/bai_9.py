#Bài 9
import math
x = int(input("nhap vao so x: "))
f = math.log(x,4) + math.log(2,x)
print(f"ket qua la: {f:.2f}")
